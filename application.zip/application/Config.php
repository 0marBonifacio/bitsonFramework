<?php
	
	define('BASE_URL', 'http://starkbyte.bit/bitson/');
	define('DEFAULT_CONTROLLER', 'index');
	define('DEFAULT_LAYOUT', 'layout1');
	
	define('APP_NAME', 'Bitson');
	define('APP_SLOGAN', 'Un Framework MVC');
	define('APP_COMPANY', 'StarkSoft');
	
	define('DB_HOST', '127.0.0.1');
	define('DB_USER', 'root');
	define('DB_PASS', '12345');
	define('DB_NAME', 'Bitson');
	define('DB_CHAR', 'utf8');
	
	define('SESSION_TIME', 10);
	
	define('HASH_KEY','5487b724bd771');