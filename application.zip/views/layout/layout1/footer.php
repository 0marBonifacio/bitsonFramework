		</div>
		<footer>
			<div class="container_12">      
				<div class="grid_12">					
					<div class="copy">
						Copyright &copy; 2014 <?php echo APP_COMPANY; ?>
						<br> 
						Framework Desarrollado por Omar Bonifacio
					</div>         
				</div>
			</div>  
		</footer>
		<script src="<?php echo $_layoutArgs['ruta_js']; ?>classie.js"></script>
		<script src="<?php echo $_layoutArgs['ruta_js']; ?>thumbnailGridEffects.js"></script>
	</body>
</html>
