			<div id="footer" class="">
				Copyright &copy; 2014 <?php echo APP_COMPANY; ?>
			</div>
		</div>
	</body>
</html>
